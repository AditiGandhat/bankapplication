package bankapplication;

public class Bank 
{
	private String name,email,accountno;
	private int contactno;
	private double balance;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAccountno() {
		return accountno;
	}
	public void setAccountno(String accountno) {
		this.accountno = accountno;
	}
	public int getContactno() {
		return contactno;
	}
	public void setContactno(int contactno) {
		this.contactno = contactno;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public Bank(String name, String email, String accountno, int contactno, double balance) {
		super();
		this.name = name;
		this.email = email;
		this.accountno = accountno;
		this.contactno = contactno;
		this.balance = balance;
	}
	
	@Override
	public String toString() {
		return "Bank [name=" + name + ", email=" + email + ", accountno=" + accountno + ", contactno=" + contactno
				+ ", balance=" + balance + "]";
	}
	
	
}
