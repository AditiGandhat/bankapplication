package bankapplication;
import java.util.Scanner;
public class Banktest {

	public static void main(String[] args) 
	{
		Bank[] bank=new Bank[30];
		String name,email,accountno;
		int contactno,choice,count=0;
		double balance=0,deposit,withdraw;
		
		Scanner sc=new Scanner(System.in);
		do {
			System.out.println("Enter your choice\nl.Create account\t2.Deposit money\t    3.Withdraw money\t 4.Show current balance\t   5.Exit");
			choice=sc.nextInt();
			
			switch(choice)
			{
			case 1:
				System.out.println("Enter your name: ");
				name=sc.next();
				System.out.println("Enter your email: ");
				email=sc.next();
				System.out.println("Enter accountno: ");
				accountno=sc.next();
				System.out.println("Enter you contact no: ");
				contactno=sc.nextInt();
				bank[count]=new Bank(name,email,accountno,contactno,balance);
				count++;
				break;
				
			case 2:
				System.out.println("Enter the amount to be deposited: ");
				deposit=sc.nextDouble();
				balance=balance+deposit;
				System.out.println("Transaction successfull\nCurrent balance is: "+balance);
				break;
			case 3:
				System.out.println("Enter the amount to be withdrawed: ");
				withdraw=sc.nextDouble();
				balance=balance-withdraw;
				System.out.println("Transaction successfull\nCurrent balance is: "+balance);
				break;
			case 4:
				System.out.println("Enter Accountno:");
				accountno=sc.next();
				System.out.println("Current balance is "+balance);
				break;
			case 5:
				System.out.println("Exit");
				System.out.println("Thank You\nVisit Again");
				break;
			}
			
				

	}while(choice !=5);

}}
